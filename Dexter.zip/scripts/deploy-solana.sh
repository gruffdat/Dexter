#!/bin/bash
# Solana deployment script
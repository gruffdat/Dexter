#!/bin/bash
# Ethereum deployment script